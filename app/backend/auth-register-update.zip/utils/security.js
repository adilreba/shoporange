"use strict";
/**
 * Security Utilities
 * IP extraction, security headers, and request validation
 * Updated: bcrypt for password hashing
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.securityHeaders = void 0;
exports.validatePasswordStrength = validatePasswordStrength;
exports.detectSQLInjection = detectSQLInjection;
exports.logSecurityEvent = logSecurityEvent;
exports.getClientIP = getClientIP;
exports.isValidEmail = isValidEmail;
exports.isValidPhone = isValidPhone;
exports.sanitizeInput = sanitizeInput;
exports.checkRateLimit = checkRateLimit;
exports.generateSecureToken = generateSecureToken;
exports.hashPassword = hashPassword;
exports.verifyPassword = verifyPassword;
exports.isBcryptHash = isBcryptHash;
exports.verifyPasswordLegacy = verifyPasswordLegacy;
const bcrypt_1 = __importDefault(require("bcrypt"));
/**
 * Validate password strength
 */
function validatePasswordStrength(password) {
    const errors = [];
    if (password.length < 8) {
        errors.push('Şifre en az 8 karakter olmalıdır');
    }
    if (!/[A-Z]/.test(password)) {
        errors.push('En az bir büyük harf içermelidir');
    }
    if (!/[a-z]/.test(password)) {
        errors.push('En az bir küçük harf içermelidir');
    }
    if (!/[0-9]/.test(password)) {
        errors.push('En az bir rakam içermelidir');
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        errors.push('En az bir özel karakter içermelidir');
    }
    return {
        isValid: errors.length === 0,
        valid: errors.length === 0, // Legacy compatibility
        errors,
    };
}
/**
 * SQL Injection detection
 */
function detectSQLInjection(input) {
    const sqlPatterns = [
        /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\b)/i,
        /(\b(OR|AND)\b.*=.*)/i,
        /(--|#|\/\*)/,
        /(\bUNION\b.*\bSELECT\b)/i,
    ];
    return sqlPatterns.some(pattern => pattern.test(input));
}
/**
 * Log security event (legacy compatibility)
 * Supports multiple signatures for backward compatibility
 */
async function logSecurityEvent(eventOrType, details, severity) {
    // Handle string signature: logSecurityEvent('TYPE', { details }, 'medium')
    if (typeof eventOrType === 'string') {
        console.log(JSON.stringify({
            _logType: 'SECURITY_EVENT',
            timestamp: new Date().toISOString(),
            type: eventOrType,
            details: details || {},
            severity: severity || 'medium',
        }));
        return;
    }
    // Handle object signature
    console.log(JSON.stringify({
        _logType: 'SECURITY_EVENT',
        timestamp: new Date().toISOString(),
        ...eventOrType,
    }));
}
/**
 * Extract client IP from various sources
 */
function getClientIP(event) {
    return (event.headers?.['X-Forwarded-For']?.split(',')[0]?.trim() ||
        event.headers?.['x-forwarded-for']?.split(',')[0]?.trim() ||
        event.requestContext?.identity?.sourceIp ||
        'unknown');
}
/**
 * Security headers for all responses
 */
exports.securityHeaders = {
    'Content-Type': 'application/json',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Strict-Transport-Security': 'max-age=63072000; includeSubDomains; preload',
    'Content-Security-Policy': "default-src 'self'",
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'geolocation=(), microphone=(), camera=()',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
};
/**
 * Validate email format
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
/**
 * Validate phone format (basic)
 */
function isValidPhone(phone) {
    const digits = phone.replace(/\D/g, '');
    return digits.length >= 10 && digits.length <= 15;
}
/**
 * Sanitize string input (basic XSS prevention)
 */
function sanitizeInput(input) {
    return input
        .replace(/[<>]/g, '')
        .replace(/javascript:/gi, '')
        .replace(/on\w+=/gi, '')
        .trim();
}
/**
 * Rate limiting helper (simple in-memory implementation)
 * For production, use Redis or DynamoDB
 */
const rateLimitStore = new Map();
function checkRateLimit(identifier, maxRequests = 100, windowMs = 60000) {
    const now = Date.now();
    const record = rateLimitStore.get(identifier);
    if (!record || now > record.resetTime) {
        // New window
        rateLimitStore.set(identifier, {
            count: 1,
            resetTime: now + windowMs,
        });
        return { allowed: true, remaining: maxRequests - 1, resetTime: now + windowMs };
    }
    if (record.count >= maxRequests) {
        return { allowed: false, remaining: 0, resetTime: record.resetTime };
    }
    record.count++;
    return {
        allowed: true,
        remaining: maxRequests - record.count,
        resetTime: record.resetTime,
    };
}
/**
 * Generate secure random token
 */
function generateSecureToken(length = 32) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let token = '';
    for (let i = 0; i < length; i++) {
        token += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return token;
}
// Bcrypt configuration
const SALT_ROUNDS = 12; // Industry standard (10-12 rounds)
/**
 * Hash password using bcrypt
 * Industry-standard password hashing with automatic salt
 * @param password Plain text password
 * @returns Bcrypt hashed password
 */
async function hashPassword(password) {
    try {
        const hashedPassword = await bcrypt_1.default.hash(password, SALT_ROUNDS);
        return hashedPassword;
    }
    catch (error) {
        console.error('Password hashing error:', error);
        throw new Error('Failed to hash password');
    }
}
/**
 * Verify password using bcrypt
 * @param password Plain text password
 * @param hashedPassword Bcrypt hashed password
 * @returns boolean indicating if password matches
 */
async function verifyPassword(password, hashedPassword) {
    try {
        const isMatch = await bcrypt_1.default.compare(password, hashedPassword);
        return isMatch;
    }
    catch (error) {
        console.error('Password verification error:', error);
        return false;
    }
}
/**
 * Check if a password hash is using bcrypt format
 * bcrypt hashes start with $2a$, $2b$, or $2y$
 */
function isBcryptHash(hash) {
    return /^\$2[aby]\$/.test(hash);
}
/**
 * Legacy password verification (for migration)
 * Supports both old pbkdf2 format and new bcrypt format
 */
async function verifyPasswordLegacy(password, hashedPassword) {
    // Check if it's a bcrypt hash
    if (isBcryptHash(hashedPassword)) {
        return verifyPassword(password, hashedPassword);
    }
    // Legacy pbkdf2 format (salt:hash)
    const crypto = await Promise.resolve().then(() => __importStar(require('crypto')));
    const [salt, hash] = hashedPassword.split(':');
    if (!salt || !hash)
        return false;
    const verifyHash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
    return hash === verifyHash;
}
//# sourceMappingURL=security.js.map