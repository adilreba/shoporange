"use strict";
/**
 * AUDIT LOGGING MODULE
 * GDPR / KVKK compliant audit trail for all sensitive operations
 * Tüm hassas işlemler için denetim kaydı
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.audit = void 0;
exports.logAuditEvent = logAuditEvent;
exports.getUserAuditLogs = getUserAuditLogs;
exports.generateUserDataReport = generateUserDataReport;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamodb = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION || 'eu-west-1' });
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamodb);
const AUDIT_LOG_TABLE = process.env.AUDIT_LOG_TABLE || 'AtusHome-AuditLogs';
// Log audit event
async function logAuditEvent(event) {
    const entry = {
        ...event,
        logId: `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        timestamp: new Date().toISOString(),
    };
    try {
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: AUDIT_LOG_TABLE,
            Item: entry,
        }));
        // Also log to CloudWatch for real-time monitoring
        console.log(`[AUDIT] ${entry.severity.toUpperCase()} ${entry.eventType}:`, {
            userId: entry.userId,
            action: entry.action,
            resource: entry.resource,
            success: entry.success,
            ipAddress: entry.ipAddress,
        });
    }
    catch (error) {
        console.error('Failed to write audit log:', error);
        // Don't throw - audit failure shouldn't break the main flow
    }
}
// Query audit logs for a user (GDPR/KVKK data portability)
async function getUserAuditLogs(userId, startDate, endDate) {
    try {
        const params = {
            TableName: AUDIT_LOG_TABLE,
            IndexName: 'UserIdIndex',
            KeyConditionExpression: 'userId = :userId',
            ExpressionAttributeValues: {
                ':userId': userId,
            },
            ScanIndexForward: false, // Newest first
        };
        if (startDate && endDate) {
            params.KeyConditionExpression += ' AND #timestamp BETWEEN :start AND :end';
            params.ExpressionAttributeNames = { '#timestamp': 'timestamp' };
            params.ExpressionAttributeValues[':start'] = startDate;
            params.ExpressionAttributeValues[':end'] = endDate;
        }
        const result = await docClient.send(new lib_dynamodb_1.QueryCommand(params));
        return (result.Items || []);
    }
    catch (error) {
        console.error('Failed to query audit logs:', error);
        return [];
    }
}
// Helper functions for common audit events
exports.audit = {
    // User authentication events
    login: async (params) => {
        await logAuditEvent({
            eventType: 'USER_LOGIN',
            severity: params.success ? 'info' : 'warning',
            action: 'LOGIN',
            resource: 'USER',
            resourceId: params.userId,
            userId: params.userId,
            userEmail: params.email,
            ipAddress: params.ipAddress,
            userAgent: params.userAgent,
            success: params.success,
            errorMessage: params.errorMessage,
            sessionId: params.sessionId,
            details: {
                method: 'email_password',
            },
        });
    },
    logout: async (params) => {
        await logAuditEvent({
            eventType: 'USER_LOGOUT',
            severity: 'info',
            action: 'LOGOUT',
            resource: 'USER',
            resourceId: params.userId,
            userId: params.userId,
            userEmail: params.email,
            ipAddress: params.ipAddress,
            success: true,
            sessionId: params.sessionId,
            details: {},
        });
    },
    // Order events
    orderCreate: async (params) => {
        await logAuditEvent({
            eventType: 'ORDER_CREATE',
            severity: params.success ? 'info' : 'error',
            action: 'CREATE',
            resource: 'ORDER',
            resourceId: params.orderId,
            userId: params.userId,
            userEmail: params.email,
            ipAddress: params.ipAddress,
            success: params.success,
            errorMessage: params.errorMessage,
            details: {
                amount: params.amount,
                itemCount: params.items.length,
                // Don't log full item details for privacy
            },
        });
    },
    // Payment events
    paymentAttempt: async (params) => {
        await logAuditEvent({
            eventType: params.success ? 'PAYMENT_SUCCESS' : 'PAYMENT_FAILURE',
            severity: params.success ? 'info' : 'error',
            action: 'PAYMENT',
            resource: 'PAYMENT',
            resourceId: params.orderId,
            userId: params.userId,
            userEmail: params.email,
            ipAddress: params.ipAddress,
            success: params.success,
            errorMessage: params.errorMessage,
            details: {
                amount: params.amount,
                paymentMethod: params.paymentMethod,
                // Never store card details!
            },
        });
    },
    // Data privacy events (GDPR/KVKK)
    dataExport: async (params) => {
        await logAuditEvent({
            eventType: 'DATA_EXPORT',
            severity: 'warning',
            action: 'EXPORT',
            resource: 'USER_DATA',
            resourceId: params.userId,
            userId: params.userId,
            userEmail: params.email,
            ipAddress: params.ipAddress,
            success: true,
            details: {
                reason: params.reason,
            },
        });
    },
    dataDelete: async (params) => {
        await logAuditEvent({
            eventType: 'DATA_DELETE',
            severity: 'critical',
            action: 'DELETE',
            resource: 'USER_DATA',
            resourceId: params.userId,
            userId: params.userId,
            userEmail: params.email,
            ipAddress: params.ipAddress,
            success: true,
            details: {
                reason: params.reason,
            },
        });
    },
    // Admin actions
    adminAction: async (params) => {
        await logAuditEvent({
            eventType: 'ADMIN_ACTION',
            severity: 'warning',
            action: params.action,
            resource: params.resource,
            resourceId: params.resourceId,
            userId: params.adminId,
            userEmail: params.adminEmail,
            ipAddress: params.ipAddress,
            success: true,
            details: params.details || {},
        });
    },
    // User self-service actions
    userAction: async (params) => {
        await logAuditEvent({
            eventType: 'USER_UPDATE',
            severity: 'info',
            action: params.action,
            resource: params.resource,
            resourceId: params.resourceId,
            userId: params.userId,
            userEmail: params.userEmail,
            ipAddress: params.ipAddress,
            success: true,
            details: params.details || {},
        });
    },
    // Security alerts
    securityAlert: async (params) => {
        await logAuditEvent({
            eventType: params.eventType,
            severity: params.severity,
            action: params.action,
            resource: 'SECURITY',
            ipAddress: params.ipAddress,
            success: false,
            errorMessage: params.errorMessage,
            details: params.details || {},
        });
    },
    // Direct access to logAuditEvent
    logAuditEvent,
};
// GDPR/KVKK compliance: Generate user data report
async function generateUserDataReport(userId) {
    // This would aggregate all user data for GDPR data portability
    // Implementation depends on your data model
    return {
        userInfo: {},
        orders: [],
        auditLogs: await getUserAuditLogs(userId),
        generatedAt: new Date().toISOString(),
    };
}
//# sourceMappingURL=auditLogger.js.map