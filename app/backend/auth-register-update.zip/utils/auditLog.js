"use strict";
/**
 * Audit Logging System
 * Security event logging for compliance (GDPR, PCI-DSS, SOC2)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.audit = exports.logDataAccessEvent = exports.logSecurityEvent = void 0;
exports.logAuditEvent = logAuditEvent;
exports.logAuthEvent = logAuthEvent;
exports.logOrderEvent = logOrderEvent;
exports.logPaymentEvent = logPaymentEvent;
exports.logAdminEvent = logAdminEvent;
exports.logDataAccess = logDataAccess;
exports.logSecurityAlert = logSecurityAlert;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION || 'eu-west-1' });
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const AUDIT_LOGS_TABLE = process.env.AUDIT_LOGS_TABLE || 'AuditLogs';
/**
 * Main audit logging function
 */
async function logAuditEvent(event) {
    const auditRecord = {
        ...event,
        timestamp: new Date().toISOString(),
        // TTL: 7 years for compliance (PCI-DSS requires 1 year)
        ttl: Math.floor(Date.now() / 1000) + 7 * 365 * 24 * 60 * 60,
    };
    // Always log to CloudWatch
    console.log(JSON.stringify({
        _logType: 'AUDIT_EVENT',
        ...auditRecord,
    }));
    // Also save to DynamoDB for queryable audit trail
    try {
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: AUDIT_LOGS_TABLE,
            Item: auditRecord,
        }));
    }
    catch (error) {
        // Don't fail the operation if audit logging fails
        // But log the error for investigation
        console.error('Failed to write audit log to DynamoDB:', error);
    }
}
/**
 * User authentication events
 */
async function logAuthEvent(params) {
    await logAuditEvent({
        eventType: params.eventType,
        severity: params.success ? 'info' : 'warning',
        action: params.eventType,
        resource: 'USER',
        resourceId: params.userId,
        userId: params.userId,
        userEmail: params.email,
        ipAddress: params.ipAddress,
        userAgent: params.userAgent,
        success: params.success,
        errorMessage: params.failureReason,
        details: {
            method: params.eventType === 'USER_LOGIN' ? 'password' : 'registration',
        },
    });
}
/**
 * Order events
 */
async function logOrderEvent(params) {
    await logAuditEvent({
        eventType: params.eventType,
        severity: params.success ? 'info' : 'warning',
        action: params.eventType,
        resource: 'ORDER',
        resourceId: params.orderId,
        userId: params.userId,
        userEmail: params.email,
        ipAddress: params.ipAddress,
        success: params.success,
        details: {
            amount: params.amount,
            ...params.details,
        },
    });
}
/**
 * Payment events
 */
async function logPaymentEvent(params) {
    await logAuditEvent({
        eventType: params.eventType,
        severity: params.success ? 'info' : 'error',
        action: params.eventType,
        resource: 'PAYMENT',
        resourceId: params.paymentId,
        userId: params.userId,
        userEmail: params.email,
        ipAddress: params.ipAddress,
        success: params.success,
        errorCode: params.errorCode,
        errorMessage: params.errorMessage,
        details: {
            orderId: params.orderId,
            amount: params.amount,
            paymentMethod: params.paymentMethod.substring(0, 4) + '***', // Mask sensitive info
        },
    });
}
/**
 * Admin action events
 */
async function logAdminEvent(params) {
    await logAuditEvent({
        eventType: 'ADMIN_ACTION',
        severity: 'warning', // Admin actions are always warning level for visibility
        action: params.action,
        resource: params.resource,
        resourceId: params.resourceId,
        userId: params.adminId,
        userEmail: params.adminEmail,
        userRole: 'admin',
        ipAddress: params.ipAddress,
        success: true,
        details: params.details,
    });
}
/**
 * Data access events (GDPR compliance)
 */
async function logDataAccess(params) {
    await logAuditEvent({
        eventType: params.action === 'export' ? 'DATA_EXPORT' : params.action === 'delete' ? 'DATA_DELETE' : 'ADMIN_ACTION',
        severity: params.action === 'delete' ? 'critical' : 'warning',
        action: `DATA_${params.action.toUpperCase()}`,
        resource: params.dataType.toUpperCase(),
        userId: params.userId,
        userEmail: params.email,
        ipAddress: params.ipAddress,
        success: params.success,
        details: {
            dataType: params.dataType,
            targetUserId: params.targetUserId,
        },
    });
}
/**
 * Security alert events
 */
async function logSecurityAlert(params) {
    await logAuditEvent({
        eventType: 'SECURITY_ALERT',
        severity: params.severity,
        action: params.alertType.toUpperCase(),
        resource: 'SECURITY',
        userId: params.userId,
        ipAddress: params.ipAddress,
        success: false,
        details: params.details,
    });
}
/**
 * Legacy compatibility exports
 */
exports.logSecurityEvent = logAuditEvent;
exports.logDataAccessEvent = logDataAccess;
// Convenience exports for orders handler
exports.audit = {
    logAuditEvent,
    auth: logAuthEvent,
    orderCreate: (params) => logOrderEvent({ ...params, eventType: 'ORDER_CREATE' }),
    orderView: (params) => logOrderEvent({ ...params, eventType: 'ORDER_VIEW' }),
    orderCancel: (params) => logOrderEvent({ ...params, eventType: 'ORDER_CANCEL' }),
    payment: logPaymentEvent,
    adminAction: logAdminEvent,
    dataAccess: logDataAccess,
    securityAlert: logSecurityAlert,
};
exports.default = exports.audit;
//# sourceMappingURL=auditLog.js.map