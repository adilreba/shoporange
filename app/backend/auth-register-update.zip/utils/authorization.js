"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserFromToken = getUserFromToken;
exports.getUserId = getUserId;
exports.requireAuth = requireAuth;
exports.requireRole = requireRole;
exports.requireAdmin = requireAdmin;
exports.requireStaff = requireStaff;
exports.unauthorizedResponse = unauthorizedResponse;
exports.isSuperAdmin = isSuperAdmin;
exports.checkAdminAccess = checkAdminAccess;
exports.checkSuperAdmin = checkSuperAdmin;
exports.forbiddenResponse = forbiddenResponse;
/**
 * Extract user information from Cognito Authorizer claims
 */
function getUserFromToken(event) {
    const claims = event.requestContext.authorizer?.claims;
    if (!claims || !claims.sub) {
        return null;
    }
    // Parse cognito:groups - can be an array or a string representation of array
    let groups = [];
    const rawGroups = claims['cognito:groups'];
    if (rawGroups) {
        if (Array.isArray(rawGroups)) {
            groups = rawGroups;
        }
        else if (typeof rawGroups === 'string') {
            // Sometimes Cognito sends groups as a string like "[admin, editor]" or JSON array
            const trimmed = rawGroups.trim();
            if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
                try {
                    groups = JSON.parse(trimmed);
                }
                catch {
                    // Fallback: split by comma
                    groups = trimmed
                        .slice(1, -1)
                        .split(',')
                        .map((g) => g.trim().replace(/^"|"$/g, ''))
                        .filter(Boolean);
                }
            }
            else {
                groups = [trimmed];
            }
        }
    }
    // Determine role: prefer cognito:groups, then custom:role, default to 'user'
    const role = groups.length > 0
        ? groups[0]
        : (claims['custom:role'] || 'user');
    return {
        userId: claims.sub,
        email: claims.email || '',
        name: claims.name || claims.email || '',
        role,
        groups,
    };
}
/**
 * Get user ID from token, with optional fallback for local testing
 */
function getUserId(event) {
    const user = getUserFromToken(event);
    if (user) {
        return user.userId;
    }
    // Local test fallback - ONLY for development without authorizer
    const mockUserId = event.headers['x-mock-user-id'] || event.queryStringParameters?.userId;
    if (mockUserId) {
        return mockUserId;
    }
    return 'guest';
}
/**
 * Require authentication - returns user or throws an error response
 */
function requireAuth(event) {
    const user = getUserFromToken(event);
    if (!user) {
        // This should not happen if Cognito Authorizer is properly configured,
        // but we handle it gracefully for local testing
        const mockUserId = event.headers['x-mock-user-id'];
        const mockEmail = event.headers['x-mock-user-email'];
        if (mockUserId && mockEmail) {
            return {
                userId: mockUserId,
                email: mockEmail,
                name: event.headers['x-mock-user-name'] || mockEmail,
                role: event.headers['x-mock-user-role'] || 'user',
                groups: [],
            };
        }
        throw new Error('UNAUTHORIZED');
    }
    return user;
}
/**
 * Check if user has required role
 */
function requireRole(event, allowedRoles) {
    const user = requireAuth(event);
    const userRoles = [user.role, ...user.groups];
    const hasRole = userRoles.some(role => allowedRoles.includes(role));
    if (!hasRole) {
        throw new Error('FORBIDDEN');
    }
    return user;
}
/**
 * Check if user is admin or super_admin
 */
function requireAdmin(event) {
    return requireRole(event, ['admin', 'super_admin']);
}
/**
 * Check if user has staff privileges (admin, super_admin, editor, support)
 */
function requireStaff(event) {
    return requireRole(event, ['admin', 'super_admin', 'editor', 'support']);
}
/**
 * Create standardized unauthorized response
 */
function unauthorizedResponse(message = 'Authentication required') {
    return {
        statusCode: 401,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ error: message, timestamp: new Date().toISOString() }),
    };
}
/**
 * Check if user is super_admin
 */
function isSuperAdmin(event) {
    const user = getUserFromToken(event);
    if (!user)
        return false;
    const userRoles = [user.role, ...user.groups];
    return userRoles.includes('super_admin');
}
/**
 * Legacy admin access check returning detailed result object
 */
function checkAdminAccess(event) {
    const user = getUserFromToken(event);
    if (!user) {
        return { allowed: false, reason: 'Authentication required' };
    }
    const userRoles = [user.role, ...user.groups];
    const isAdmin = userRoles.some(role => ['admin', 'super_admin'].includes(role));
    if (!isAdmin) {
        return { allowed: false, reason: 'Admin access required' };
    }
    return { allowed: true };
}
/**
 * Check if user is super_admin (legacy boolean return)
 */
function checkSuperAdmin(event) {
    return isSuperAdmin(event);
}
/**
 * Create standardized forbidden response
 */
function forbiddenResponse(message = 'Insufficient permissions') {
    return {
        statusCode: 403,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ error: message, timestamp: new Date().toISOString() }),
    };
}
//# sourceMappingURL=authorization.js.map