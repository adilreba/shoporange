"use strict";
/**
 * AWS KMS Encryption Utilities
 * PII encryption at rest for GDPR/HIPAA compliance
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.encryptField = encryptField;
exports.decryptField = decryptField;
exports.encryptObjectFields = encryptObjectFields;
exports.decryptObjectFields = decryptObjectFields;
exports.generateDataKey = generateDataKey;
exports.isEncrypted = isEncrypted;
exports.maskSensitiveData = maskSensitiveData;
exports.maskEmail = maskEmail;
exports.maskPhone = maskPhone;
exports.maskCreditCard = maskCreditCard;
exports.hashSensitiveData = hashSensitiveData;
exports.encryptSensitiveData = encryptSensitiveData;
exports.decryptSensitiveData = decryptSensitiveData;
const client_kms_1 = require("@aws-sdk/client-kms");
// KMS Client
const kms = new client_kms_1.KMSClient({ region: process.env.AWS_REGION || 'eu-west-1' });
const KMS_KEY_ID = process.env.KMS_KEY_ID;
// Field-level encryption configuration
const ENCRYPTED_FIELD_MARKER = '__ENC__';
/**
 * Encrypt a single field value using KMS
 */
async function encryptField(plaintext, context) {
    if (!KMS_KEY_ID) {
        console.error('KMS_KEY_ID not configured');
        throw new Error('Encryption service unavailable');
    }
    if (!plaintext)
        return plaintext;
    try {
        const command = new client_kms_1.EncryptCommand({
            KeyId: KMS_KEY_ID,
            Plaintext: Buffer.from(plaintext, 'utf-8'),
            EncryptionContext: context,
        });
        const result = await kms.send(command);
        const encrypted = Buffer.from(result.CiphertextBlob).toString('base64');
        return `${ENCRYPTED_FIELD_MARKER}${encrypted}`;
    }
    catch (error) {
        console.error('KMS encryption error:', error);
        throw new Error('Failed to encrypt sensitive data');
    }
}
/**
 * Decrypt a single field value using KMS
 */
async function decryptField(encrypted, context) {
    if (!encrypted || !encrypted.startsWith(ENCRYPTED_FIELD_MARKER)) {
        return encrypted;
    }
    const ciphertext = encrypted.slice(ENCRYPTED_FIELD_MARKER.length);
    try {
        const command = new client_kms_1.DecryptCommand({
            CiphertextBlob: Buffer.from(ciphertext, 'base64'),
            EncryptionContext: context,
        });
        const result = await kms.send(command);
        return Buffer.from(result.Plaintext).toString('utf-8');
    }
    catch (error) {
        console.error('KMS decryption error:', error);
        throw new Error('Failed to decrypt sensitive data');
    }
}
/**
 * Encrypt object fields recursively
 */
async function encryptObjectFields(obj, fieldsToEncrypt, context = { service: 'orders', purpose: 'pii-protection' }) {
    const encrypted = { ...obj };
    for (const field of fieldsToEncrypt) {
        if (obj[field]) {
            if (typeof obj[field] === 'object') {
                // Recursively encrypt nested objects
                encrypted[field] = await encryptObjectFields(obj[field], Object.keys(obj[field]), context);
            }
            else if (typeof obj[field] === 'string') {
                encrypted[field] = await encryptField(obj[field], context);
            }
        }
    }
    return encrypted;
}
/**
 * Decrypt object fields recursively
 */
async function decryptObjectFields(obj, fieldsToDecrypt, context = { service: 'orders', purpose: 'pii-protection' }) {
    const decrypted = { ...obj };
    for (const field of fieldsToDecrypt) {
        if (obj[field]) {
            if (typeof obj[field] === 'object') {
                // Recursively decrypt nested objects
                decrypted[field] = await decryptObjectFields(obj[field], Object.keys(obj[field]), context);
            }
            else if (typeof obj[field] === 'string') {
                decrypted[field] = await decryptField(obj[field], context);
            }
        }
    }
    return decrypted;
}
/**
 * Generate data key for envelope encryption (useful for large data)
 */
async function generateDataKey() {
    if (!KMS_KEY_ID) {
        throw new Error('KMS_KEY_ID not configured');
    }
    const command = new client_kms_1.GenerateDataKeyCommand({
        KeyId: KMS_KEY_ID,
        KeySpec: 'AES_256',
    });
    const result = await kms.send(command);
    return {
        ciphertext: Buffer.from(result.CiphertextBlob).toString('base64'),
        plaintext: Buffer.from(result.Plaintext),
    };
}
/**
 * Check if a value is encrypted
 */
function isEncrypted(value) {
    return typeof value === 'string' && value.startsWith(ENCRYPTED_FIELD_MARKER);
}
/**
 * Mask sensitive data for logging/display
 */
function maskSensitiveData(obj, fieldsToMask) {
    const masked = { ...obj };
    for (const field of fieldsToMask) {
        if (obj[field]) {
            if (typeof obj[field] === 'string') {
                if (field === 'email') {
                    masked[field] = maskEmail(obj[field]);
                }
                else if (field === 'phone') {
                    masked[field] = maskPhone(obj[field]);
                }
                else if (field === 'creditCard') {
                    masked[field] = maskCreditCard(obj[field]);
                }
                else {
                    masked[field] = '***';
                }
            }
        }
    }
    return masked;
}
/**
 * Mask email address
 * example: user@example.com -> u***@example.com
 */
function maskEmail(email) {
    if (!email || !email.includes('@'))
        return email;
    const [local, domain] = email.split('@');
    const maskedLocal = local[0] + '***';
    return `${maskedLocal}@${domain}`;
}
/**
 * Mask phone number
 * example: +90 555 123 45 67 -> +90 *** ** ** 67
 */
function maskPhone(phone) {
    if (!phone)
        return phone;
    const digits = phone.replace(/\D/g, '');
    if (digits.length < 4)
        return phone;
    const last4 = digits.slice(-4);
    const countryCode = phone.startsWith('+') ? phone.split(' ')[0] : '';
    return `${countryCode} *** ** ** ${last4}`;
}
/**
 * Mask credit card number
 * example: 4532 **** **** 1234
 */
function maskCreditCard(card) {
    if (!card)
        return card;
    const digits = card.replace(/\D/g, '');
    if (digits.length < 4)
        return card;
    const last4 = digits.slice(-4);
    return `**** **** **** ${last4}`;
}
/**
 * Hash sensitive data (one-way, for comparison/anonymization)
 */
async function hashSensitiveData(data, salt) {
    const crypto = await Promise.resolve().then(() => __importStar(require('crypto')));
    const hash = crypto.createHash('sha256');
    hash.update(data + (salt || process.env.HASH_SALT || 'default_salt'));
    return hash.digest('hex');
}
/**
 * Legacy compatibility exports
 */
async function encryptSensitiveData(plaintext, context) {
    return encryptField(plaintext, context);
}
async function decryptSensitiveData(encrypted, context) {
    return decryptField(encrypted, context);
}
//# sourceMappingURL=encryption.js.map