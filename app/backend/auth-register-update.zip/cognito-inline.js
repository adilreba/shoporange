"use strict";
// COGNITO SERVICE - INLINE VERSION
// This file is copied from services/cognito.ts for SAM deployment
Object.defineProperty(exports, "__esModule", { value: true });
exports.signUp = signUp;
exports.confirmSignUp = confirmSignUp;
exports.resendConfirmationCode = resendConfirmationCode;
exports.signIn = signIn;
exports.refreshTokens = refreshTokens;
exports.getUser = getUser;
exports.signOut = signOut;
exports.forgotPassword = forgotPassword;
exports.confirmForgotPassword = confirmForgotPassword;
exports.adminCreateUser = adminCreateUser;
exports.adminUpdateUserRole = adminUpdateUserRole;
exports.adminGetUser = adminGetUser;
exports.handleGoogleSignIn = handleGoogleSignIn;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const client = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
    region: process.env.AWS_REGION || 'eu-west-1',
});
const USER_POOL_ID = process.env.COGNITO_USER_POOL_ID || '';
const CLIENT_ID = process.env.COGNITO_CLIENT_ID || '';
async function signUp(input) {
    const command = new client_cognito_identity_provider_1.SignUpCommand({
        ClientId: CLIENT_ID,
        Username: input.email,
        Password: input.password,
        UserAttributes: [
            { Name: 'email', Value: input.email },
            { Name: 'name', Value: input.name },
            ...(input.phone ? [{ Name: 'phone_number', Value: input.phone }] : []),
            { Name: 'custom:role', Value: 'user' },
        ],
    });
    const response = await client.send(command);
    return { userSub: response.UserSub };
}
async function confirmSignUp(email, code) {
    const command = new client_cognito_identity_provider_1.ConfirmSignUpCommand({
        ClientId: CLIENT_ID,
        Username: email,
        ConfirmationCode: code,
    });
    await client.send(command);
}
async function resendConfirmationCode(email) {
    const command = new client_cognito_identity_provider_1.ResendConfirmationCodeCommand({
        ClientId: CLIENT_ID,
        Username: email,
    });
    await client.send(command);
}
async function signIn(input) {
    const command = new client_cognito_identity_provider_1.InitiateAuthCommand({
        ClientId: CLIENT_ID,
        AuthFlow: client_cognito_identity_provider_1.AuthFlowType.USER_PASSWORD_AUTH,
        AuthParameters: {
            USERNAME: input.email,
            PASSWORD: input.password,
        },
    });
    const response = await client.send(command);
    const authResult = response.AuthenticationResult;
    if (!authResult?.AccessToken || !authResult?.IdToken || !authResult?.RefreshToken) {
        throw new Error('Authentication failed');
    }
    const user = await getUser(authResult.AccessToken);
    return {
        user: {
            id: user.sub,
            email: user.email,
            name: user.name,
            phone: user.phone,
            role: user['custom:role'] || 'user',
        },
        tokens: {
            accessToken: authResult.AccessToken,
            idToken: authResult.IdToken,
            refreshToken: authResult.RefreshToken,
            expiresIn: authResult.ExpiresIn || 3600,
        },
    };
}
async function refreshTokens(refreshToken) {
    const command = new client_cognito_identity_provider_1.InitiateAuthCommand({
        ClientId: CLIENT_ID,
        AuthFlow: client_cognito_identity_provider_1.AuthFlowType.REFRESH_TOKEN_AUTH,
        AuthParameters: {
            REFRESH_TOKEN: refreshToken,
        },
    });
    const response = await client.send(command);
    const authResult = response.AuthenticationResult;
    if (!authResult?.AccessToken || !authResult?.IdToken) {
        throw new Error('Token refresh failed');
    }
    return {
        tokens: {
            accessToken: authResult.AccessToken,
            idToken: authResult.IdToken,
            refreshToken: refreshToken,
            expiresIn: authResult.ExpiresIn || 3600,
        },
    };
}
async function getUser(accessToken) {
    const command = new client_cognito_identity_provider_1.GetUserCommand({
        AccessToken: accessToken,
    });
    const response = await client.send(command);
    const attributes = {};
    response.UserAttributes?.forEach((attr) => {
        if (attr.Name && attr.Value) {
            attributes[attr.Name] = attr.Value;
        }
    });
    return {
        sub: attributes.sub,
        email: attributes.email,
        name: attributes.name,
        phone: attributes.phone_number,
        'custom:role': attributes['custom:role'],
    };
}
async function signOut(accessToken) {
    const command = new client_cognito_identity_provider_1.GlobalSignOutCommand({
        AccessToken: accessToken,
    });
    await client.send(command);
}
async function forgotPassword(email) {
    const command = new client_cognito_identity_provider_1.ForgotPasswordCommand({
        ClientId: CLIENT_ID,
        Username: email,
    });
    await client.send(command);
}
async function confirmForgotPassword(email, code, newPassword) {
    const command = new client_cognito_identity_provider_1.ConfirmForgotPasswordCommand({
        ClientId: CLIENT_ID,
        Username: email,
        ConfirmationCode: code,
        Password: newPassword,
    });
    await client.send(command);
}
async function adminCreateUser(email, name, temporaryPassword, role = 'user') {
    const command = new client_cognito_identity_provider_1.AdminCreateUserCommand({
        UserPoolId: USER_POOL_ID,
        Username: email,
        UserAttributes: [
            { Name: 'email', Value: email },
            { Name: 'email_verified', Value: 'true' },
            { Name: 'name', Value: name },
            { Name: 'custom:role', Value: role },
        ],
        TemporaryPassword: temporaryPassword,
        MessageAction: 'SUPPRESS',
    });
    await client.send(command);
    const setPasswordCommand = new client_cognito_identity_provider_1.AdminSetUserPasswordCommand({
        UserPoolId: USER_POOL_ID,
        Username: email,
        Password: temporaryPassword,
        Permanent: true,
    });
    await client.send(setPasswordCommand);
}
async function adminUpdateUserRole(email, newRole) {
    const command = new client_cognito_identity_provider_1.AdminUpdateUserAttributesCommand({
        UserPoolId: USER_POOL_ID,
        Username: email,
        UserAttributes: [
            { Name: 'custom:role', Value: newRole },
        ],
    });
    await client.send(command);
}
async function adminGetUser(email) {
    const command = new client_cognito_identity_provider_1.AdminGetUserCommand({
        UserPoolId: USER_POOL_ID,
        Username: email,
    });
    const response = await client.send(command);
    const attributes = {};
    response.UserAttributes?.forEach((attr) => {
        if (attr.Name && attr.Value) {
            attributes[attr.Name] = attr.Value;
        }
    });
    return {
        username: response.Username,
        email: attributes.email,
        name: attributes.name,
        role: attributes['custom:role'] || 'user',
        emailVerified: attributes.email_verified === 'true',
        createdAt: response.UserCreateDate,
        lastModifiedAt: response.UserLastModifiedDate,
        status: response.UserStatus,
    };
}
async function handleGoogleSignIn(googleUser, idToken) {
    try {
        return await signIn({
            email: googleUser.email,
            password: `google_${googleUser.sub}`,
        });
    }
    catch (error) {
        const tempPassword = `google_${googleUser.sub}_${Date.now()}`;
        await adminCreateUser(googleUser.email, googleUser.name, tempPassword, 'user');
        return await signIn({
            email: googleUser.email,
            password: tempPassword,
        });
    }
}
//# sourceMappingURL=cognito-inline.js.map