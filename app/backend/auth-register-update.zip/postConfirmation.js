"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({ region: process.env.AWS_REGION || 'eu-west-1' });
const dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION || 'eu-west-1' });
const dynamodb = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const USER_POOL_ID = process.env.COGNITO_USER_POOL_ID || '';
const USERS_TABLE = process.env.USERS_TABLE || '';
const handler = async (event) => {
    try {
        const userAttributes = event.request.userAttributes;
        const userSub = userAttributes.sub;
        const email = userAttributes.email;
        const name = userAttributes.name || email.split('@')[0];
        const role = userAttributes['custom:role'] || 'user';
        console.log('[PostConfirmation] Processing user:', email, 'sub:', userSub);
        // 1. Ensure custom:role is set to user if not already set
        if (!userAttributes['custom:role']) {
            await cognitoClient.send(new client_cognito_identity_provider_1.AdminUpdateUserAttributesCommand({
                UserPoolId: USER_POOL_ID,
                Username: event.userName,
                UserAttributes: [
                    { Name: 'custom:role', Value: 'user' },
                ],
            }));
            console.log('[PostConfirmation] Set custom:role to user');
        }
        // 2. Add user to the default 'user' Cognito group
        await cognitoClient.send(new client_cognito_identity_provider_1.AdminAddUserToGroupCommand({
            UserPoolId: USER_POOL_ID,
            Username: event.userName,
            GroupName: 'user',
        }));
        console.log('[PostConfirmation] Added user to group: user');
        // 3. Create user profile in DynamoDB
        if (USERS_TABLE && userSub) {
            const userProfile = {
                id: userSub,
                email,
                name,
                role,
                phone: userAttributes.phone_number || '',
                avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`,
                address: [],
                isActive: true,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
            };
            await dynamodb.send(new lib_dynamodb_1.PutCommand({
                TableName: USERS_TABLE,
                Item: userProfile,
            }));
            console.log('[PostConfirmation] Created user profile in DynamoDB');
        }
        return event;
    }
    catch (error) {
        console.error('[PostConfirmation] Error:', error);
        // Cognito triggers should still return the event even on error
        // to avoid blocking user confirmation. Log the error for monitoring.
        return event;
    }
};
exports.handler = handler;
//# sourceMappingURL=postConfirmation.js.map