"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.changePassword = exports.googleLogin = exports.resetPassword = exports.forgotPassword = exports.getMe = exports.logout = exports.refreshToken = exports.resendCode = exports.verifyEmail = exports.login = exports.register = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const security_1 = require("./utils/security");
// ===== COGNITO CLIENT SETUP =====
const cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
    region: process.env.AWS_REGION || 'eu-west-1',
});
const USER_POOL_ID = process.env.COGNITO_USER_POOL_ID || '';
const CLIENT_ID = process.env.COGNITO_CLIENT_ID || '';
// ===== COGNITO FUNCTIONS =====
async function signUp(input) {
    // E.164 format: +905551234567 (no spaces, parentheses, or dashes)
    let e164Phone = input.phone ? input.phone.replace(/\s+/g, '').replace(/[()-]/g, '') : undefined;
    // Eğer + ile başlamıyorsa ve 0 ile başlıyorsa, varsayılan olarak +90 ekle (Türkiye)
    if (e164Phone && !e164Phone.startsWith('+')) {
        e164Phone = e164Phone.startsWith('0') ? `+9${e164Phone}` : `+${e164Phone}`;
    }
    const command = new client_cognito_identity_provider_1.SignUpCommand({
        ClientId: CLIENT_ID,
        Username: input.email,
        Password: input.password,
        UserAttributes: [
            { Name: 'email', Value: input.email },
            { Name: 'name', Value: input.name },
            ...(e164Phone ? [{ Name: 'phone_number', Value: e164Phone }] : []),
            { Name: 'custom:role', Value: 'user' },
        ],
    });
    const response = await cognitoClient.send(command);
    return { userSub: response.UserSub };
}
async function confirmSignUp(email, code) {
    const command = new client_cognito_identity_provider_1.ConfirmSignUpCommand({
        ClientId: CLIENT_ID,
        Username: email,
        ConfirmationCode: code,
    });
    await cognitoClient.send(command);
}
async function resendConfirmationCode(email) {
    const command = new client_cognito_identity_provider_1.ResendConfirmationCodeCommand({
        ClientId: CLIENT_ID,
        Username: email,
    });
    await cognitoClient.send(command);
}
async function signIn(input) {
    const command = new client_cognito_identity_provider_1.InitiateAuthCommand({
        ClientId: CLIENT_ID,
        AuthFlow: client_cognito_identity_provider_1.AuthFlowType.USER_PASSWORD_AUTH,
        AuthParameters: {
            USERNAME: input.email,
            PASSWORD: input.password,
        },
    });
    const response = await cognitoClient.send(command);
    const authResult = response.AuthenticationResult;
    if (!authResult?.AccessToken || !authResult?.IdToken || !authResult?.RefreshToken) {
        throw new Error('Authentication failed');
    }
    const user = await getUser(authResult.AccessToken);
    return {
        user: {
            id: user.sub,
            email: user.email,
            name: user.name,
            phone: user.phone,
            role: user.role || 'user',
        },
        tokens: {
            accessToken: authResult.AccessToken,
            idToken: authResult.IdToken,
            refreshToken: authResult.RefreshToken,
            expiresIn: authResult.ExpiresIn || 3600,
        },
    };
}
async function refreshTokens(refreshToken) {
    const command = new client_cognito_identity_provider_1.InitiateAuthCommand({
        ClientId: CLIENT_ID,
        AuthFlow: client_cognito_identity_provider_1.AuthFlowType.REFRESH_TOKEN_AUTH,
        AuthParameters: { REFRESH_TOKEN: refreshToken },
    });
    const response = await cognitoClient.send(command);
    const authResult = response.AuthenticationResult;
    if (!authResult?.AccessToken || !authResult?.IdToken) {
        throw new Error('Token refresh failed');
    }
    return {
        tokens: {
            accessToken: authResult.AccessToken,
            idToken: authResult.IdToken,
            refreshToken: refreshToken,
            expiresIn: authResult.ExpiresIn || 3600,
        },
    };
}
async function getUser(accessToken) {
    const command = new client_cognito_identity_provider_1.GetUserCommand({ AccessToken: accessToken });
    const response = await cognitoClient.send(command);
    const attributes = {};
    response.UserAttributes?.forEach((attr) => {
        if (attr.Name && attr.Value) {
            attributes[attr.Name] = attr.Value;
        }
    });
    return {
        sub: attributes.sub,
        email: attributes.email,
        name: attributes.name,
        phone: attributes.phone_number,
        role: attributes['custom:role'] || 'user',
    };
}
async function signOut(accessToken) {
    const command = new client_cognito_identity_provider_1.GlobalSignOutCommand({ AccessToken: accessToken });
    await cognitoClient.send(command);
}
async function sendForgotPasswordCode(email) {
    const command = new client_cognito_identity_provider_1.ForgotPasswordCommand({
        ClientId: CLIENT_ID,
        Username: email,
    });
    await cognitoClient.send(command);
}
async function confirmForgotPasswordCode(email, code, newPassword) {
    const command = new client_cognito_identity_provider_1.ConfirmForgotPasswordCommand({
        ClientId: CLIENT_ID,
        Username: email,
        ConfirmationCode: code,
        Password: newPassword,
    });
    await cognitoClient.send(command);
}
async function adminCreateUser(email, name, tempPassword, role = 'user') {
    const command = new client_cognito_identity_provider_1.AdminCreateUserCommand({
        UserPoolId: USER_POOL_ID,
        Username: email,
        UserAttributes: [
            { Name: 'email', Value: email },
            { Name: 'email_verified', Value: 'true' },
            { Name: 'name', Value: name },
            { Name: 'custom:role', Value: role },
        ],
        TemporaryPassword: tempPassword,
        MessageAction: 'SUPPRESS',
    });
    await cognitoClient.send(command);
    const setPasswordCommand = new (await Promise.resolve().then(() => __importStar(require('@aws-sdk/client-cognito-identity-provider')))).AdminSetUserPasswordCommand({
        UserPoolId: USER_POOL_ID,
        Username: email,
        Password: tempPassword,
        Permanent: true,
    });
    await cognitoClient.send(setPasswordCommand);
}
async function handleGoogleSignIn(googleUser, idToken) {
    try {
        return await signIn({
            email: googleUser.email,
            password: `google_${googleUser.sub}`,
        });
    }
    catch (error) {
        const tempPassword = `google_${googleUser.sub}_${Date.now()}`;
        await adminCreateUser(googleUser.email, googleUser.name, tempPassword, 'user');
        return await signIn({ email: googleUser.email, password: tempPassword });
    }
}
// ===== RATE LIMIT CONFIG =====
// Rate limit configs
const RATE_LIMITS = {
    login: { max: 10, window: 300000 }, // 10 deneme, 5 dakika
    register: { max: 10, window: 3600000 }, // 10 deneme, 1 saat
    default: { max: 100, window: 60000 }, // 100 istek, 1 dakika
};
// Helper: Rate limit check with specific limits
const checkAuthRateLimit = (event, type) => {
    const clientIP = (0, security_1.getClientIP)(event);
    const limit = RATE_LIMITS[type] || RATE_LIMITS.default;
    return (0, security_1.checkRateLimit)(`${clientIP}:${type}`, limit.max, limit.window);
};
/**
 * POST /auth/register
 * Register a new user with security checks
 */
const register = async (event) => {
    try {
        // Rate limiting
        const rateCheck = checkAuthRateLimit(event, 'register');
        if (!rateCheck.allowed) {
            (0, security_1.logSecurityEvent)('RATE_LIMIT_EXCEEDED', { endpoint: 'register', ip: (0, security_1.getClientIP)(event) }, 'medium');
            return {
                statusCode: 429,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Too many registration attempts. Please try again later.' }),
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Request body is required' }),
            };
        }
        const { email, password, name, phone } = JSON.parse(event.body);
        // Input validation
        if (!email || !password || !name) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Email, password, and name are required' }),
            };
        }
        // Sanitize inputs
        const sanitizedEmail = (0, security_1.sanitizeInput)(email).toLowerCase();
        const sanitizedName = (0, security_1.sanitizeInput)(name);
        const sanitizedPhone = phone ? (0, security_1.sanitizeInput)(phone) : undefined;
        // Validate email format (strict)
        const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
        if (!emailRegex.test(sanitizedEmail)) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Invalid email format' }),
            };
        }
        // SQL injection check
        if ((0, security_1.detectSQLInjection)(sanitizedEmail) || (0, security_1.detectSQLInjection)(sanitizedName)) {
            (0, security_1.logSecurityEvent)('SQL_INJECTION_ATTEMPT', { endpoint: 'register', email: sanitizedEmail }, 'high');
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Invalid input detected' }),
            };
        }
        // Validate password strength
        const passwordCheck = (0, security_1.validatePasswordStrength)(password);
        if (!passwordCheck.valid) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({
                    error: 'Password does not meet security requirements',
                    details: passwordCheck.errors,
                }),
            };
        }
        const result = await signUp({
            email: sanitizedEmail,
            password,
            name: sanitizedName,
            phone: sanitizedPhone,
        });
        (0, security_1.logSecurityEvent)('USER_REGISTERED', { email: sanitizedEmail }, 'low');
        return {
            statusCode: 201,
            headers: security_1.securityHeaders,
            body: JSON.stringify({
                message: 'User registered successfully. Please check your email for verification code.',
                userId: result.userSub,
            }),
        };
    }
    catch (error) {
        console.error('Register error:', error);
        if (error.name === 'UsernameExistsException') {
            try {
                // Kullanıcı zaten kayıtlıysa, doğrulama kodunu tekrar göndermeyi dene
                // (Eğer kullanıcı zaten confirmed ise bu da hata verir, o zaman 'already exists' döneriz)
                await resendConfirmationCode(JSON.parse(event.body || '{}').email || '');
                return {
                    statusCode: 200,
                    headers: security_1.securityHeaders,
                    body: JSON.stringify({
                        message: 'Verification code resent. Please check your email.',
                        needsVerification: true,
                    }),
                };
            }
            catch (resendError) {
                // Kod tekrar gönderilemezse (örn. zaten confirmed), kayıtlı olduğunu söyle
                return {
                    statusCode: 409,
                    headers: security_1.securityHeaders,
                    body: JSON.stringify({ error: 'Bu e-posta adresi zaten kayıtlı. Lütfen giriş yapın veya şifrenizi sıfırlayın.' }),
                };
            }
        }
        if (error.name === 'InvalidPasswordException') {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: error.message }),
            };
        }
        return {
            statusCode: 500,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ error: 'Registration failed' }),
        };
    }
};
exports.register = register;
/**
 * POST /auth/login
 * Login with rate limiting and security checks
 */
const login = async (event) => {
    try {
        // Rate limiting - brute force protection
        const clientIP = (0, security_1.getClientIP)(event);
        const rateCheck = checkAuthRateLimit(event, 'login');
        if (!rateCheck.allowed) {
            (0, security_1.logSecurityEvent)('BRUTE_FORCE_ATTEMPT', { endpoint: 'login', ip: clientIP }, 'high');
            return {
                statusCode: 429,
                headers: security_1.securityHeaders,
                body: JSON.stringify({
                    error: 'Too many login attempts. Account temporarily locked. Please try again in 5 minutes.'
                }),
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Request body is required' }),
            };
        }
        const { email, password } = JSON.parse(event.body);
        if (!email || !password) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Email and password are required' }),
            };
        }
        // Sanitize email
        const sanitizedEmail = (0, security_1.sanitizeInput)(email).toLowerCase();
        // SQL injection check
        if ((0, security_1.detectSQLInjection)(sanitizedEmail)) {
            (0, security_1.logSecurityEvent)('SQL_INJECTION_ATTEMPT', { endpoint: 'login', email: sanitizedEmail }, 'high');
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Invalid input detected' }),
            };
        }
        const result = await signIn({
            email: sanitizedEmail,
            password,
        });
        (0, security_1.logSecurityEvent)('USER_LOGGED_IN', { email: sanitizedEmail, ip: clientIP }, 'low');
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({
                user: result.user,
                token: result.tokens.idToken,
                accessToken: result.tokens.accessToken,
                refreshToken: result.tokens.refreshToken,
                expiresIn: result.tokens.expiresIn,
            }),
        };
    }
    catch (error) {
        console.error('Login error:', error);
        if (error.name === 'NotAuthorizedException') {
            (0, security_1.logSecurityEvent)('FAILED_LOGIN', { email: (0, security_1.sanitizeInput)(JSON.parse(event.body || '{}').email || '') }, 'medium');
            return {
                statusCode: 401,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Invalid email or password' }),
            };
        }
        if (error.name === 'UserNotConfirmedException') {
            return {
                statusCode: 403,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Email not verified. Please check your email.' }),
            };
        }
        return {
            statusCode: 500,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ error: 'Login failed' }),
        };
    }
};
exports.login = login;
/**
 * POST /auth/verify
 * Verify email with security checks
 */
const verifyEmail = async (event) => {
    try {
        // Rate limiting
        const rateCheck = checkAuthRateLimit(event, 'login');
        if (!rateCheck.allowed) {
            (0, security_1.logSecurityEvent)('RATE_LIMIT_EXCEEDED', { endpoint: 'verifyEmail', ip: (0, security_1.getClientIP)(event) }, 'medium');
            return {
                statusCode: 429,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Too many verification attempts. Please try again later.' }),
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Request body is required' }),
            };
        }
        const { email, code } = JSON.parse(event.body);
        if (!email || !code) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Email and verification code are required' }),
            };
        }
        const sanitizedEmail = (0, security_1.sanitizeInput)(email).toLowerCase();
        const sanitizedCode = (0, security_1.sanitizeInput)(code);
        // Verify code format (6 digits)
        if (!/^\d{6}$/.test(sanitizedCode)) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Invalid verification code format' }),
            };
        }
        await confirmSignUp(sanitizedEmail, sanitizedCode);
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ message: 'Email verified successfully' }),
        };
    }
    catch (error) {
        console.error('Verify email error:', error);
        if (error.name === 'CodeMismatchException') {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Invalid verification code' }),
            };
        }
        return {
            statusCode: 500,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ error: 'Verification failed' }),
        };
    }
};
exports.verifyEmail = verifyEmail;
/**
 * POST /auth/resend-code
 * Resend verification code
 */
const resendCode = async (event) => {
    try {
        // Rate limiting
        const rateCheck = checkAuthRateLimit(event, 'login');
        if (!rateCheck.allowed) {
            (0, security_1.logSecurityEvent)('RATE_LIMIT_EXCEEDED', { endpoint: 'resendCode', ip: (0, security_1.getClientIP)(event) }, 'medium');
            return {
                statusCode: 429,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Too many resend attempts. Please try again later.' }),
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Request body is required' }),
            };
        }
        const { email } = JSON.parse(event.body);
        if (!email) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Email is required' }),
            };
        }
        const sanitizedEmail = (0, security_1.sanitizeInput)(email).toLowerCase();
        await resendConfirmationCode(sanitizedEmail);
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ message: 'Verification code resent' }),
        };
    }
    catch (error) {
        console.error('Resend code error:', error);
        return {
            statusCode: 500,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ error: 'Failed to resend code' }),
        };
    }
};
exports.resendCode = resendCode;
/**
 * POST /auth/refresh
 * Refresh access token
 */
const refreshToken = async (event) => {
    try {
        if (!event.body) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Request body is required' }),
            };
        }
        const { refreshToken: token } = JSON.parse(event.body);
        if (!token) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Refresh token is required' }),
            };
        }
        const result = await refreshTokens(token);
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({
                token: result.tokens.idToken,
                accessToken: result.tokens.accessToken,
                refreshToken: result.tokens.refreshToken,
                expiresIn: result.tokens.expiresIn,
            }),
        };
    }
    catch (error) {
        console.error('Refresh token error:', error);
        return {
            statusCode: 401,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ error: 'Invalid refresh token' }),
        };
    }
};
exports.refreshToken = refreshToken;
/**
 * POST /auth/logout
 * Logout user
 */
const logout = async (event) => {
    try {
        const authHeader = event.headers.Authorization || event.headers.authorization;
        const accessToken = authHeader?.replace('Bearer ', '');
        if (accessToken) {
            await signOut(accessToken);
        }
        (0, security_1.logSecurityEvent)('USER_LOGGED_OUT', { ip: (0, security_1.getClientIP)(event) }, 'low');
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ message: 'Logged out successfully' }),
        };
    }
    catch (error) {
        console.error('Logout error:', error);
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ message: 'Logged out successfully' }),
        };
    }
};
exports.logout = logout;
/**
 * GET /auth/me
 * Get current user
 */
const getMe = async (event) => {
    try {
        const authHeader = event.headers.Authorization || event.headers.authorization;
        const accessToken = authHeader?.replace('Bearer ', '');
        if (!accessToken) {
            return {
                statusCode: 401,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Authorization header required' }),
            };
        }
        const user = await getUser(accessToken);
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({
                id: user.sub,
                email: user.email,
                name: user.name,
                phone: user.phone,
                role: user['custom:role'] || 'user',
            }),
        };
    }
    catch (error) {
        console.error('Get user error:', error);
        return {
            statusCode: 401,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ error: 'Invalid or expired token' }),
        };
    }
};
exports.getMe = getMe;
/**
 * POST /auth/forgot-password
 * Send password reset code
 */
const forgotPassword = async (event) => {
    try {
        if (!event.body) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Request body is required' }),
            };
        }
        const { email } = JSON.parse(event.body);
        if (!email) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Email is required' }),
            };
        }
        const sanitizedEmail = (0, security_1.sanitizeInput)(email).toLowerCase();
        await sendForgotPasswordCode(sanitizedEmail);
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ message: 'Password reset code sent to your email' }),
        };
    }
    catch (error) {
        console.error('Forgot password error:', error);
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ message: 'If email exists, password reset code sent' }),
        };
    }
};
exports.forgotPassword = forgotPassword;
/**
 * POST /auth/reset-password
 * Reset password with code
 */
const resetPassword = async (event) => {
    try {
        if (!event.body) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Request body is required' }),
            };
        }
        const { email, code, newPassword } = JSON.parse(event.body);
        if (!email || !code || !newPassword) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Email, code, and new password are required' }),
            };
        }
        // Validate new password strength
        const passwordCheck = (0, security_1.validatePasswordStrength)(newPassword);
        if (!passwordCheck.valid) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({
                    error: 'New password does not meet security requirements',
                    details: passwordCheck.errors,
                }),
            };
        }
        const sanitizedEmail = (0, security_1.sanitizeInput)(email).toLowerCase();
        await confirmForgotPasswordCode(sanitizedEmail, code, newPassword);
        (0, security_1.logSecurityEvent)('PASSWORD_RESET', { email: sanitizedEmail }, 'medium');
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ message: 'Password reset successful' }),
        };
    }
    catch (error) {
        console.error('Reset password error:', error);
        return {
            statusCode: 400,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ error: 'Password reset failed' }),
        };
    }
};
exports.resetPassword = resetPassword;
/**
 * POST /auth/google
 * Google OAuth login
 */
const googleLogin = async (event) => {
    try {
        if (!event.body) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Request body is required' }),
            };
        }
        const { token, user: googleUser } = JSON.parse(event.body);
        if (!token || !googleUser?.email) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Google token and user info are required' }),
            };
        }
        // Validate Google email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(googleUser.email)) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Invalid email format' }),
            };
        }
        const result = await handleGoogleSignIn({
            email: (0, security_1.sanitizeInput)(googleUser.email),
            name: (0, security_1.sanitizeInput)(googleUser.name),
            picture: googleUser.picture,
            sub: googleUser.sub || googleUser.id,
        }, token);
        (0, security_1.logSecurityEvent)('GOOGLE_LOGIN', { email: googleUser.email }, 'low');
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({
                user: result.user,
                token: result.tokens.idToken,
                accessToken: result.tokens.accessToken,
                refreshToken: result.tokens.refreshToken,
                expiresIn: result.tokens.expiresIn,
            }),
        };
    }
    catch (error) {
        console.error('Google login error:', error);
        return {
            statusCode: 500,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ error: 'Google login failed' }),
        };
    }
};
exports.googleLogin = googleLogin;
/**
 * POST /auth/change-password
 * Change user password with old password verification
 */
const changePassword = async (event) => {
    try {
        const authHeader = event.headers.Authorization || event.headers.authorization;
        const accessToken = authHeader?.replace('Bearer ', '');
        if (!accessToken) {
            return {
                statusCode: 401,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Authorization header required' }),
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Request body is required' }),
            };
        }
        const { oldPassword, newPassword } = JSON.parse(event.body);
        if (!oldPassword || !newPassword) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Old password and new password are required' }),
            };
        }
        const passwordCheck = (0, security_1.validatePasswordStrength)(newPassword);
        if (!passwordCheck.valid) {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({
                    error: 'New password does not meet security requirements',
                    details: passwordCheck.errors,
                }),
            };
        }
        const command = new client_cognito_identity_provider_1.ChangePasswordCommand({
            AccessToken: accessToken,
            PreviousPassword: oldPassword,
            ProposedPassword: newPassword,
        });
        await cognitoClient.send(command);
        (0, security_1.logSecurityEvent)('PASSWORD_CHANGED', { ip: (0, security_1.getClientIP)(event) }, 'medium');
        return {
            statusCode: 200,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ message: 'Password changed successfully' }),
        };
    }
    catch (error) {
        console.error('Change password error:', error);
        if (error.name === 'NotAuthorizedException' || error.name === 'InvalidPasswordException') {
            return {
                statusCode: 400,
                headers: security_1.securityHeaders,
                body: JSON.stringify({ error: 'Invalid old password or new password is too weak' }),
            };
        }
        return {
            statusCode: 500,
            headers: security_1.securityHeaders,
            body: JSON.stringify({ error: 'Password change failed' }),
        };
    }
};
exports.changePassword = changePassword;
//# sourceMappingURL=index.js.map