"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.signUp = signUp;
exports.confirmSignUp = confirmSignUp;
exports.resendConfirmationCode = resendConfirmationCode;
exports.signIn = signIn;
exports.refreshTokens = refreshTokens;
exports.getUser = getUser;
exports.signOut = signOut;
exports.forgotPassword = forgotPassword;
exports.confirmForgotPassword = confirmForgotPassword;
exports.adminCreateUser = adminCreateUser;
exports.adminUpdateUserRole = adminUpdateUserRole;
exports.adminGetUser = adminGetUser;
exports.handleGoogleSignIn = handleGoogleSignIn;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const client = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
    region: process.env.AWS_REGION || 'eu-west-1',
});
const USER_POOL_ID = process.env.COGNITO_USER_POOL_ID || '';
const CLIENT_ID = process.env.COGNITO_CLIENT_ID || '';
/**
 * Sign up a new user with email/password
 */
async function signUp(input) {
    const command = new client_cognito_identity_provider_1.SignUpCommand({
        ClientId: CLIENT_ID,
        Username: input.email,
        Password: input.password,
        UserAttributes: [
            { Name: 'email', Value: input.email },
            { Name: 'name', Value: input.name },
            ...(input.phone ? [{ Name: 'phone_number', Value: input.phone }] : []),
            { Name: 'custom:role', Value: 'user' },
        ],
    });
    const response = await client.send(command);
    return { userSub: response.UserSub };
}
/**
 * Confirm sign up with verification code
 */
async function confirmSignUp(email, code) {
    const command = new client_cognito_identity_provider_1.ConfirmSignUpCommand({
        ClientId: CLIENT_ID,
        Username: email,
        ConfirmationCode: code,
    });
    await client.send(command);
}
/**
 * Resend confirmation code
 */
async function resendConfirmationCode(email) {
    const command = new client_cognito_identity_provider_1.ResendConfirmationCodeCommand({
        ClientId: CLIENT_ID,
        Username: email,
    });
    await client.send(command);
}
/**
 * Sign in with email/password
 */
async function signIn(input) {
    const command = new client_cognito_identity_provider_1.InitiateAuthCommand({
        ClientId: CLIENT_ID,
        AuthFlow: client_cognito_identity_provider_1.AuthFlowType.USER_PASSWORD_AUTH,
        AuthParameters: {
            USERNAME: input.email,
            PASSWORD: input.password,
        },
    });
    const response = await client.send(command);
    const authResult = response.AuthenticationResult;
    if (!authResult?.AccessToken || !authResult?.IdToken || !authResult?.RefreshToken) {
        throw new Error('Authentication failed');
    }
    // Get user details
    const user = await getUser(authResult.AccessToken);
    return {
        user: {
            id: user.sub,
            email: user.email,
            name: user.name,
            phone: user.phone,
            role: user['custom:role'] || 'user',
        },
        tokens: {
            accessToken: authResult.AccessToken,
            idToken: authResult.IdToken,
            refreshToken: authResult.RefreshToken,
            expiresIn: authResult.ExpiresIn || 3600,
        },
    };
}
/**
 * Refresh tokens
 */
async function refreshTokens(refreshToken) {
    const command = new client_cognito_identity_provider_1.InitiateAuthCommand({
        ClientId: CLIENT_ID,
        AuthFlow: client_cognito_identity_provider_1.AuthFlowType.REFRESH_TOKEN_AUTH,
        AuthParameters: {
            REFRESH_TOKEN: refreshToken,
        },
    });
    const response = await client.send(command);
    const authResult = response.AuthenticationResult;
    if (!authResult?.AccessToken || !authResult?.IdToken) {
        throw new Error('Token refresh failed');
    }
    return {
        tokens: {
            accessToken: authResult.AccessToken,
            idToken: authResult.IdToken,
            refreshToken: refreshToken, // Keep the same refresh token
            expiresIn: authResult.ExpiresIn || 3600,
        },
    };
}
/**
 * Get user details from access token
 */
async function getUser(accessToken) {
    const command = new client_cognito_identity_provider_1.GetUserCommand({
        AccessToken: accessToken,
    });
    const response = await client.send(command);
    const attributes = {};
    response.UserAttributes?.forEach((attr) => {
        if (attr.Name && attr.Value) {
            attributes[attr.Name] = attr.Value;
        }
    });
    return {
        sub: attributes.sub,
        email: attributes.email,
        name: attributes.name,
        phone: attributes.phone_number,
        'custom:role': attributes['custom:role'],
    };
}
/**
 * Sign out user globally
 */
async function signOut(accessToken) {
    const command = new client_cognito_identity_provider_1.GlobalSignOutCommand({
        AccessToken: accessToken,
    });
    await client.send(command);
}
/**
 * Forgot password - send reset code
 */
async function forgotPassword(email) {
    const command = new client_cognito_identity_provider_1.ForgotPasswordCommand({
        ClientId: CLIENT_ID,
        Username: email,
    });
    await client.send(command);
}
/**
 * Confirm forgot password - reset with code
 */
async function confirmForgotPassword(email, code, newPassword) {
    const command = new client_cognito_identity_provider_1.ConfirmForgotPasswordCommand({
        ClientId: CLIENT_ID,
        Username: email,
        ConfirmationCode: code,
        Password: newPassword,
    });
    await client.send(command);
}
/**
 * Admin create user (for creating admin users)
 */
async function adminCreateUser(email, name, temporaryPassword, role = 'user') {
    const command = new client_cognito_identity_provider_1.AdminCreateUserCommand({
        UserPoolId: USER_POOL_ID,
        Username: email,
        UserAttributes: [
            { Name: 'email', Value: email },
            { Name: 'email_verified', Value: 'true' },
            { Name: 'name', Value: name },
            { Name: 'custom:role', Value: role },
        ],
        TemporaryPassword: temporaryPassword,
        MessageAction: 'SUPPRESS', // Don't send welcome email
    });
    await client.send(command);
    // Set permanent password
    const setPasswordCommand = new client_cognito_identity_provider_1.AdminSetUserPasswordCommand({
        UserPoolId: USER_POOL_ID,
        Username: email,
        Password: temporaryPassword,
        Permanent: true,
    });
    await client.send(setPasswordCommand);
}
/**
 * Admin: Update user role (custom:role attribute)
 */
async function adminUpdateUserRole(email, newRole) {
    const command = new client_cognito_identity_provider_1.AdminUpdateUserAttributesCommand({
        UserPoolId: USER_POOL_ID,
        Username: email,
        UserAttributes: [
            { Name: 'custom:role', Value: newRole },
        ],
    });
    await client.send(command);
}
/**
 * Admin: Get user details including custom attributes
 */
async function adminGetUser(email) {
    const command = new client_cognito_identity_provider_1.AdminGetUserCommand({
        UserPoolId: USER_POOL_ID,
        Username: email,
    });
    const response = await client.send(command);
    // Convert attributes to object
    const attributes = {};
    response.UserAttributes?.forEach((attr) => {
        if (attr.Name && attr.Value) {
            attributes[attr.Name] = attr.Value;
        }
    });
    return {
        username: response.Username,
        email: attributes.email,
        name: attributes.name,
        role: attributes['custom:role'] || 'user',
        emailVerified: attributes.email_verified === 'true',
        createdAt: response.UserCreateDate,
        lastModifiedAt: response.UserLastModifiedDate,
        status: response.UserStatus,
    };
}
/**
 * Handle Google sign in - create or get existing user
 * FIRST ADMIN: Add your email to SUPER_ADMIN_EMAILS for automatic super_admin role
 */
const SUPER_ADMIN_EMAILS = [
    // Add your Google email here for automatic super_admin access
    // Example: 'yourname@gmail.com'
    process.env.SUPER_ADMIN_EMAIL || '',
].filter(Boolean);
async function handleGoogleSignIn(googleUser, idToken) {
    try {
        // First try to sign in (user might already exist)
        return await signIn({
            email: googleUser.email,
            password: `google_${googleUser.sub}`,
        });
    }
    catch (error) {
        // User doesn't exist, create them
        const tempPassword = `google_${googleUser.sub}_${Date.now()}`;
        // Check if this email should be super_admin
        const isSuperAdmin = SUPER_ADMIN_EMAILS.includes(googleUser.email.toLowerCase());
        const role = isSuperAdmin ? 'super_admin' : 'user';
        console.log(`[Google SignIn] Creating user: ${googleUser.email}, Role: ${role}`);
        await adminCreateUser(googleUser.email, googleUser.name, tempPassword, role);
        // Now sign in
        return await signIn({
            email: googleUser.email,
            password: tempPassword,
        });
    }
}
//# sourceMappingURL=cognito.js.map